#!/bin/bash

#verificar si colo el argumento se pasa la palabra  help
if [ "$1" == "help" ]; then
cat help
exit  0

#validar si hay dos argumentos
elif [ $# -ne 2 ]; then
echo "Error:ingrese dos parametros (origen y destino)"
   exit 1
fi

#validar que los directorios de origen y destion estén disponibles
if [ ! -d "$1" ]; then
echo "Error: el directorio ingresado no está disponible"
elif [ ! -d "$2" ]; then
echo "Error: el directorio intresado no está disponible"
exit 1

fi

#Fecha en formato ANSI (YYYYMMDD)
FECHA=$(date +%Y%m%d)

#Nombre del archivo de backup
BACKUP=$(basename "$1")_bkp$FECHA.tar.gz

#crear el backup
tar -czf "$2/$BACKUP" -C "$1" .

#verificar si el backup se creó correctamente
if [[ $? -eq 0 ]]; then
echo "el backup se creó exitosamente"
else
echo "Error al realizar el backup"
exit 1
fi












